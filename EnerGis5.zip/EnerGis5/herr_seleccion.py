﻿# encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2018 Juan Messina
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

from PyQt5.QtWidgets import *
from qgis.gui import QgsMapTool
from qgis.utils import iface
from qgis.core import QgsRectangle, QgsFeatureRequest

tecla=''

class herrSeleccion(QgsMapTool):   
    def __init__(self, canvas):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    

    def keyPressEvent(self, event):
        #QMessageBox.information(None, "Mensaje", str(event.key()))
        global tecla
        if str(event.key()) == '16777249':
            tecla = 'Ctrl'
            #QMessageBox.information(None, "Mensaje", str(event.key()))
            pass
            
    def keyReleaseEvent(self, event):
        global tecla
        #QMessageBox.information(None, "Mensaje", tecla)
        tecla = ''
        
    def canvasPressEvent(self, event):
        #si no tengo apretada Ctrl borro la seleccion anterior
        global tecla
        if tecla != 'Ctrl':
            n = self.canvas.layerCount()
            layers = [self.canvas.layer(i) for i in range(n)]
            for lyr in layers:
                lyr.removeSelection()
            pass

    def canvasMoveEvent(self, event):
        pass

    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        n = self.canvas.layerCount()
        layers = [self.canvas.layer(i) for i in range(n)]
        #hacemos que se busque en las capas que queremos !!!
        for lyr in layers:
            #QMessageBox.information(None, 'EnerGis', 'nodo ' + str(lyr.name()))
            if lyr.name()[:6] == 'Lineas' or lyr.name()[:5] == 'Nodos':
                #QMessageBox.information(None, "doble click", " x: " + str(lyr.name()) )
                #QMessageBox.information(None, "doble click", " x: " + str(point.x()) + " Y: " + str(point.y()) )
                width = 4 * self.canvas.mapUnitsPerPixel()
                rect = QgsRectangle(point.x() - width, point.y() - width, point.x() + width, point.y() + width)
                #rect = self.canvas.mapRenderer().mapToLayerCoordinates(lyr, rect)                
                int = QgsFeatureRequest().setFilterRect(rect).setFlags(QgsFeatureRequest.ExactIntersect)
                ftrs = lyr.getFeatures(int)
                for ftr in ftrs:
                    lyr.select(ftr.id())
                    return
        pass

    def canvasDoubleClickEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        n = self.canvas.layerCount()
        layers = [self.canvas.layer(i) for i in range(n)]
        #hacemos que se busque en las capas que queremos !!!
        for lyr in layers:
            #QMessageBox.information(None, 'EnerGis', 'nodo ' + str(lyr.name()))
            if lyr.name()[:6] == 'Lineas' or lyr.name()[:5] == 'Nodos':
                #QMessageBox.information(None, "doble click", " x: " + str(lyr.name()) )
                #QMessageBox.information(None, "doble click", " x: " + str(point.x()) + " Y: " + str(point.y()) )
                width = 6 * self.canvas.mapUnitsPerPixel()                
                rect = QgsRectangle(point.x() - width, point.y() - width, point.x() + width, point.y() + width)
                #rect = self.canvas.mapRenderer().mapToLayerCoordinates(lyr, rect)
                int = QgsFeatureRequest().setFilterRect(rect).setFlags(QgsFeatureRequest.ExactIntersect)
                ftrs = lyr.getFeatures(int)
                for ftr in ftrs:
                    lyr.select(ftr.id())
                    QMessageBox.information(None, "Mensaje", str(lyr.name()) + ': ' + str(ftr.id()))
                    return
        pass

    def activate(self):
        pass
        
    def deactivate(self):
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return True