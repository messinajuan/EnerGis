EnerGis 4
===================
Armado de entorno para interactuar con una base de datos de EnerGis
