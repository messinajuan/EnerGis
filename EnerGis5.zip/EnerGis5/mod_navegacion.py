﻿# encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2018 Juan Messina
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

from PyQt5.QtWidgets import *
import os

#esta es la direccion del proyecto
basepath = os.path.dirname(os.path.realpath(__file__))

def navegar_a_los_extremos (mnodos, mlineas, nodo, fuentes):
#------------------------------------------------------------------------------------
#esta rutina navega la red desde un nodo cualquiera  y marca el camino a los extremos
#------------------------------------------------------------------------------------
    fuente_nav = 0
    try:
        lineas_del_nodo = []
        proximos_nodos = []
        cant_lineas_del_nodo = buscar_lineas_segun_nodo(mnodos, mlineas, nodo, lineas_del_nodo, proximos_nodos)
        #analizo todas las salidas y voy guardando pendientes
        nodos_anulados = []
        lineas_anuladas = []
        caminos_a_fuentes = 0
        #f = open(os.path.join(basepath,"salidas", 'navegar_a_los_extremos.txt'), 'w')
        #f.write('Navegar desde nodo: ' + str(nodo))
        #f.close()
        for n in range (0, cant_lineas_del_nodo):
            #borro todo rastro de las lineas para la segunda rutina (detectar_fuente)
            for m in range (0, len(mlineas)):
                mlineas[m][8] = 0
            #primero marco la línea para la segunda rutina (detectar_fuente)
            mlineas[lineas_del_nodo[n]][8] = 1
            fuente_nav = detectar_fuente(mnodos, mlineas, proximos_nodos[n], nodos_anulados, fuentes)
            if fuente_nav == 0:
                pass
                #msgbox_ nodo & ":no llego a ninguna fuente"
            else:
                #msgbox_ nodo & ":si llego, a la fuente : " & fuente_nav
                caminos_a_fuentes = caminos_a_fuentes + 1
                nodos_anulados.append(proximos_nodos[n])
                lineas_anuladas.append(lineas_del_nodo[n])
                fuentenavegada = fuente_nav

        if caminos_a_fuentes == cant_lineas_del_nodo:
            mlineas[lineas_del_nodo[cant_lineas_del_nodo-1]][8]= 0  #desmarco la linea para la segunda rutina (detectar_fuente)
            return 'Navegar a los Extremos - Todos los caminos llegan a una Fuente'
        if caminos_a_fuentes == 0:
            return 'Navegar a los Extremos - Nodo Desconectado'
        #f = open(os.path.join(basepath,"salidas", 'navegar_a_los_extremos.txt'), 'a')
        #f.write('\n' + 'fuente encontrada: ' + str(fuentenavegada))
        #f.close()
        #lineas anuladas
        for m in range (0, len(lineas_anuladas)):
            mlineas[lineas_anuladas[m]][7] = fuentenavegada

        r = navegar_normalizar_red(mnodos, mlineas, nodos_anulados, nodo, fuentenavegada)
        if r != 'Navegar Normalizar Red - Fin':
            return r
        
        for m in range (0, len(lineas_anuladas)):
            mlineas[lineas_anuladas[m]][7] = 0
    except Exception as e:
        return 'Navegar a los Extremos - ' + str(e)
    
def navegar_normalizar_red(mnodos, mlineas, nodos_anulados, nodo, fuentenavegada):
#--------------------------------------------------------------------------------------
#esta rutina navega la red desde un nodo cualquiera, y marca el camino que recorre .
#--------------------------------------------------------------------------------------
    repetir = True
    pendientes = []
    try:
        while repetir == True:
            repetir = False
            if nodo == 0:
                return 'Navegar Normalizar Red - Fin'
            else:
                mnodos[nodo][40] = fuentenavegada
                #****************************************
                lineas_del_nodo = []
                proximos_nodos = []
                cant_lineas_del_nodo = buscar_lineas_segun_nodo(mnodos, mlineas, nodo, lineas_del_nodo, proximos_nodos)
                for n in range (0, cant_lineas_del_nodo):
                    if mnodos[proximos_nodos[n]][2] == 3:
                        mlineas[lineas_del_nodo[n]][7] = fuentenavegada
                        mnodos[proximos_nodos[n]][40] = fuentenavegada
                #****************************************
            if mnodos[nodo][2] == 3:
                if len(pendientes) == 0:
                    return 'Navegar Normalizar Red - Fin'
                nodo = pendientes[len(pendientes) - 1] ##tomo el nodo del ultimo valor de la lista
                pendientes.pop() ##elimino el ultimo valor de la lista
                repetir = True ##goto 1
                if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                    if nodo == 0:
                        return 'Navegar Normalizar Red - Fin'
            if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                for n in range (0, len(nodos_anulados)):
                    if nodo == nodos_anulados[n]:
                        if len(pendientes) == 0:
                            return 'Navegar Normalizar Red - Fin'
                        nodo = pendientes[len(pendientes) - 1] ##tomo el nodo del ultimo valor de la lista
                        pendientes.pop() ##elimino el ultimo valor de la lista
                        repetir = True ##goto 1
                        n = len(nodos_anulados) ##goto 1
                        if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                            if nodo == 0:
                                return 'Navegar Normalizar Red - Fin'
                if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                    lineas_del_nodo = []
                    proximos_nodos = []
                    cant_lineas_del_nodo = buscar_lineas_segun_nodo(mnodos, mlineas, nodo, lineas_del_nodo, proximos_nodos)
                    camino = -1
                    #escojo el primer camino aún no recorrido
                    for n in range (0, cant_lineas_del_nodo):
                        if mlineas[lineas_del_nodo[n]][7] == 0:
                            camino = n
                            n = cant_lineas_del_nodo
                    linea_navegando = lineas_del_nodo[camino]
                    mlineas[linea_navegando][7] = fuentenavegada
                    ##agrego los caminos pendientes que aun no estan pendientes
                    for n in range (0, cant_lineas_del_nodo):
                        if mlineas[lineas_del_nodo[n]][7] == 0:
                            pendientes.append(proximos_nodos[n])
                    if camino != -1:
                        nodo = proximos_nodos[camino]
                    else:
                        if mnodos[nodo][4] == 1: ##ultimo nodo (de cada spur)
                            mlineas[mnodos[nodo][5]][7] = fuentenavegada
                        ##si cambia la tension del pendiente blanqueo el ultimo trafo navegado
                            ##eso falta
                        ##paso al nodo siguiente
                        if len(pendientes) == 0:
                            return 'Navegar Normalizar Red - Fin'
                        nodo = pendientes[len(pendientes) - 1] ##tomo el nodo del ultimo valor de la lista
                        pendientes.pop() ##elimino el ultimo valor de la lista
                    if nodo == 0:
                        return 'Navegar Normalizar Red - Fin'
            repetir = True
    except Exception as e:
        return 'Navegar Normalizar Red - ' + str(e)        
    
def navegar_a_la_fuente(mnodos, mlineas, nodo, fuentes, lineas_ordenadas):
#--------------------------------------------------------------------------------
#esta rutina navega la red desde un nodo cualquiera y marca un camino a la fuente
#--------------------------------------------------------------------------------
    fuente_nav = 0
    nodos_anulados = []
    for m in range (0, len(mlineas)):
        mlineas[m][7] = 0
    repetir = True
    try:
        while repetir == True:
            repetir = False
            lineas_del_nodo = []
            proximos_nodos = []
            cant_lineas_del_nodo = buscar_lineas_segun_nodo(mnodos, mlineas, nodo, lineas_del_nodo, proximos_nodos)
            #analizo todas las salidas y voy guardando pendientes
            if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                for m in range (0, cant_lineas_del_nodo):
                    repetir2 = False
                    for t in range (0, len(nodos_anulados)):
                        if nodos_anulados[t] == proximos_nodos[m]:
                            repetir2 = True #goto 1
                    if repetir2 == False:
                        for t in range (0, len(mlineas)):
                            mlineas[t][8] = 0
                        nodos_anulados.append(nodo)
                        fuente_nav = detectar_fuente(mnodos, mlineas, proximos_nodos[m], nodos_anulados, fuentes)
                        if fuente_nav == 0:
                            pass
                            #msgbox_ nodo & ":no llego a ninguna fuente"
                        else:
                            #msgbox_ nodo & ":si llego, a la fuente : " & fuente_nav
                            mlineas[lineas_del_nodo[m]][7] = 1
                            lineas_ordenadas.append(lineas_del_nodo[m])
                            nodo = proximos_nodos[m]
                            repetir = True
        return fuente_nav
    except Exception as e:
        return 'Navegacion - ' + str(e)

def detectar_fuente(mnodos, mlineas, nodo, nodos_anulados, fuentes):
#--------------------------------------------------------------------------------------
#esta funcion navega la red desde un nodo cualquiera, hacia una direccion, e indica si llega
#a una fuente ( marca si el nodo esta conectado por ese camino )
#--------------------------------------------------------------------------------------
    nodo_2 = nodo
    cant_fuentes = len(fuentes)
    repetir = True
    try:
        pendientes_2 = []
        #mnodos[fuente_navegada][3] = fuente_navegada
        while repetir == True:
            repetir = False
            for w in range (0, len(nodos_anulados)):
                if nodo_2 == nodos_anulados[w]:
                    nodo_2 = pendientes_2[len(pendientes_2) - 1] ##tomo el nodo del ultimo valor de la lista
                    pendientes_2.pop() ##elimino el ultimo valor de la lista
                    repetir = True ##goto 1
                    w = len(nodos_anulados) ##goto 1
            if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                if mnodos[nodo_2][2] == 3:
                    nodo_2 = pendientes_2[len(pendientes_2) - 1] ##tomo el nodo del ultimo valor de la lista
                    pendientes_2.pop() ##elimino el ultimo valor de la lista
                    repetir = True ##goto 1
                    if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                        if nodo_2 == 0:
                            return 0
                if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                    for x in range (0, cant_fuentes):
                        if nodo_2 == fuentes[x]:
                            return nodo_2
                    #analizo las líneas del nodo : nodo
                    ##****************************************
                    lineas_del_nodo_2 = []
                    proximos_nodos_2 = []
                    cant_lineas_del_nodo_2 = buscar_lineas_segun_nodo(mnodos, mlineas, nodo_2, lineas_del_nodo_2, proximos_nodos_2)
                    ##****************************************
                    camino = -1
                    #escojo el primer camino aun no recorrido
                    for x in range(0, cant_lineas_del_nodo_2):
                        if mlineas[lineas_del_nodo_2[x]][8] == 0:
                            camino = x
                            x = cant_lineas_del_nodo_2
                    linea_navegando = lineas_del_nodo_2[camino]
                    mlineas[linea_navegando][8] = camino + 2
                    ##****************************************
                    #agrego los caminos pendientes que aun no estan pendientes
                    for x in range (0, cant_lineas_del_nodo_2):
                        if mlineas[lineas_del_nodo_2[x]][8] == 0:
                            pendientes_2.append(proximos_nodos_2[x])
                            ##****************************************
                    if camino != -1:
                        nodo_2 = proximos_nodos_2[camino]
                    else:
                        nodo_2 = pendientes_2[len(pendientes_2) - 1]
                        pendientes_2.pop()
                    if nodo_2 != 0:
                        for x in range (0, cant_fuentes):
                            if nodo_2 == fuentes[x]:
                                return nodo_2
            repetir = True
        return 0
    except Exception as e:
        return 0 #'Navegacion - Verificar nodo: ' + str(mnodos[nodo_2][1]) + ' - ' + str(e)

def navegar_compilar_red(monodos, mnodos, mlineas, fuente_navegada):
##--------------------------------------------------------------------------------------
##esta rutina navega la red desde una fuente y marca el camino que recorre .
##--------------------------------------------------------------------------------------
    l = 0
    m = 0
    n = 0
    nodo = 0
    trafo_navegado = 0
    nodo_anterior = 0
    ##****************************************
    ##Dic 2012, le agregamos i_nodos_ordenados para que haya un orden a pesar de varias fuentes
    ##****************************************
    nodo = fuente_navegada
    pendientes = []
    repetir = True
    ##****************************************
    try:
        mnodos[fuente_navegada][3] = fuente_navegada
        while repetir == True:
            repetir = False
            if nodo == 0:
                ##me fijo si me quedo algun seccionador abierto sin ordenar, se pone al final
                for n in range (0, len(mnodos)):
                    if mnodos[n][2] == 3: ##es un seccionador abierto
                        if mnodos[n][40] == 0:
                            monodos.append(n)
                            mnodos[n][40] = len(monodos)
                return 'Red Navegada'
            else:
                ##****************************************
                if mnodos[nodo][40] == 0:
                    monodos.append(nodo)
                    mnodos[nodo][40] = len(monodos)
                ##****************************************
                mnodos[nodo][3] = fuente_navegada
                mnodos[nodo][41] = trafo_navegado
                ##****************************************
                ##al trafo le dejo el id del trafo aguas arriba y a partir de aca el id es este
                if mnodos[nodo][2] == 4:
                    trafo_navegado = nodo
                ##****************************************
                lineas_del_nodo=[]
                proximos_nodos=[]
                cant_lineas_del_nodo = buscar_lineas_segun_nodo(mnodos, mlineas, nodo, lineas_del_nodo, proximos_nodos)
                ##****************************************
                for n in range (0, cant_lineas_del_nodo):
                    if mnodos[proximos_nodos[n]][2] == 3:
                        ##como el ultimo nodo de cada spur
                        mlineas[lineas_del_nodo[n]][4] = fuente_navegada
                        mnodos[proximos_nodos[n]][3] = fuente_navegada #26/7 #mnodos[nodo][3]
                        mnodos[proximos_nodos[n]][41] = trafo_navegado
                        ##aca no dejo pendientes porque se trata de una seccionador abierto
            ##****************************************
            if mnodos[nodo][2] == 3:
                ##como el ultimo nodo de cada spur
                ##Aca esta suponiendo que el seccionador abierto tiene una sola línea que le llega, pero esta mal
                ##hay que marcar la linea del lado que venia navegando.
                mlineas[mnodos[nodo][5]][4] = fuente_navegada
                ##si cambia la tension del pendiente blanqueo el ultimo trafo navegado
                    ##eso falta
                ##paso al nodo siguiente
                nodo_anterior = nodo
                if len(pendientes) > 0:
                    nodo = pendientes[len(pendientes) - 1] ##tomo el nodo del ultimo valor de la lista
                    pendientes.pop() ##elimino el ultimo valor de la lista
                    #f = open(os.path.join(basepath,"salidas", 'salida_navegacion.txt'), 'a')
                    #f.write('\n' + 'tomo del ultimo pendiente nodo: ' + str(nodo) + ', pendientes: ' + str(len(pendientes)))
                    #f.close()
                    repetir = True ##goto 1
            if repetir == False: ##si repetir=True voy hasta el fondo para iterar
                ##****************************************
                lineas_del_nodo=[]
                proximos_nodos=[]
                cant_lineas_del_nodo = buscar_lineas_segun_nodo(mnodos, mlineas, nodo, lineas_del_nodo, proximos_nodos)
                ##****************************************
                camino = -1
                ##escojo el primer camino aún no recorrido 
                for n in range (0, cant_lineas_del_nodo):
                    if mlineas[lineas_del_nodo[n]][4] == 0:
                        camino = n
                        n = cant_lineas_del_nodo + 1
                linea_navegando = lineas_del_nodo[camino]
                mlineas[linea_navegando][4] = fuente_navegada
                #f = open(os.path.join(basepath,"salidas", 'salida_navegacion.txt'), 'a')
                #f.write('\n' + 'Elijo seguir por el nodo: ' + str(proximos_nodos[camino]))
                #f.close()
                ##****************************************
                ##agrego los caminos pendientes que aún no estan pendientes
                for n in range (0, cant_lineas_del_nodo):
                    if camino != n:
                        if mlineas[lineas_del_nodo[n]][4] == 0:
                            pendientes.append(proximos_nodos[n])
                            #f = open(os.path.join(basepath,"salidas", 'salida_navegacion.txt'), 'a')
                            #f.write('\n' + 'Agrego a pendientes nodo: ' + str(proximos_nodos[n]) + ', pendientes: ' + str(len(pendientes)))
                            #f.close()
                            ##****************************************
                if camino != -1:
                    ##si cambia la tension del pendiente blanqueo el ultimo trafo navegado
                        ##eso falta
                    ##paso al nodo siguiente
                    nodo_anterior = nodo
                    nodo = proximos_nodos[camino]
                    mnodos[nodo][3] = fuente_navegada
                    mnodos[nodo][39] = mnodos[nodo][39] + 1
                else:
                    if mnodos[nodo][4] == 1: ##ultimo nodo (de cada spur)
                        mlineas[mnodos[nodo][5]][4] = fuente_navegada
                    ##si cambia la tension del pendiente blanqueo el ultimo trafo navegado
                        ##eso falta
                    ##paso al nodo siguiente
                    nodo_anterior = nodo
                    if len(pendientes) == 0:
                        return 'Red Navegada'
                    nodo = pendientes[len(pendientes) - 1] ##tomo el nodo del ultimo valor de la lista
                    pendientes.pop() ##elimino el ultimo valor de la lista
                    #f = open(os.path.join(basepath,"salidas", 'salida_navegacion.txt'), 'a')
                    #f.write('\n' + 'Tomo del ultimo pendiente nodo: ' + str(nodo) + ', pendientes: ' + str(len(pendientes)))
                    #f.close()
            repetir = True
        return 'Verificar Navegacion'
    except Exception as e:
        return 'Navegacion - Verificar nodo: ' + str(mnodos[nodo][1]) + ' - ' + str(e)
    
def buscar_lineas_segun_nodo(mnodos, mlineas, nodo_buscado, lineas_del_nodo, proximos_nodos):
##--------------------------------------------------------------------------------------
##esta función devuelve una lista de lineas que tocan a un nodo (hasta 32), la cantidad
##y la lista de nodos a los que se dirigen esas lineas, y ordenados como las mismas
##--------------------------------------------------------------------------------------
    cant_lineas_del_nodo = 0
    try:
        cant_lineas_del_nodo = mnodos[nodo_buscado][4]
        for m in range (0, cant_lineas_del_nodo):
            linea = mnodos[nodo_buscado][m + 5]
            lineas_del_nodo.append(linea)
            if nodo_buscado == mlineas[linea][3]:
                proximos_nodos.append(mlineas[linea][2])
            else:
                if nodo_buscado == mlineas[linea][2]:
                    proximos_nodos.append(mlineas[linea][3])
                else:
                    return '0' #'nodo: ' + str(nodo_buscado) + 'linea: ' + str(linea) + ' - desde: ' + str(mlineas[linea][3]) + ' - hasta: ' + str(mlineas[linea][2])
        return cant_lineas_del_nodo
    except Exception as e:
        return '0' #str(e) + 'nodo: ' + str(nodo_buscado) + ' - cant_lineas: ' + str(cant_lineas_del_nodo)