﻿import os
from PyQt5.QtWidgets import *
from PyQt5 import uic
from qgis.utils import iface
from qgis.core import QgsFeatureRequest, QgsExpression
    
DialogBase, DialogType = uic.loadUiType(os.path.join(os.path.dirname(__file__),'frm_seleccion.ui'))

class frmSeleccion(DialogType, DialogBase):

    def __init__(self, mapcanvas):
        super().__init__()
        self.setupUi(self)
        self.inicio()
        self.setFixedSize(self.size())
        self.mapcanvas = mapcanvas
        self.liwNodos.itemClicked.connect(self.elijo_nodo)
        self.liwLineas.itemClicked.connect(self.elijo_linea)

    def inicio(self):
        #QMessageBox.information(None, 'EnerGis', 'Inicio')
        pass

    def elijo_nodo(self):
        #QMessageBox.information(None, 'EnerGis', str(self.liwNodos.selectedItems()[0].text()))
        n = self.mapcanvas.layerCount()
        layers = [self.mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            if lyr.name()[:5] == 'Nodos':
                sel = lyr.selectedFeatures()
                id = int(self.liwNodos.selectedItems()[0].text())
                for ftr in sel:
                    if ftr.id()==id:
                        geom = ftr.geometry()
                        #box = geom.boundingBox()
                        box = geom.buffer(25,1).boundingBox()
                        self.mapcanvas.setExtent(box)
                        self.mapcanvas.refresh()

    def elijo_linea(self):
        n = self.mapcanvas.layerCount()
        layers = [self.mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            if lyr.name()[:6] == 'Lineas':
                sel = lyr.selectedFeatures()
                id = int(self.liwLineas.selectedItems()[0].text())
                for ftr in sel:
                    if ftr.id()==id:
                        geom = ftr.geometry()
                        box = geom.boundingBox()
                        self.mapcanvas.setExtent(box)
                        self.mapcanvas.refresh()