﻿# encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2018 Juan Messina
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import Qt, QtCore, QtWidgets, QtGui, QtWebKit, QtWebKitWidgets, QtXml, QtNetwork, uic
from qgis import core, utils, gui
from qgis.core import QgsVectorLayer, QgsFeature
from qgis.gui import QgsAttributeDialog

from .herr_seleccion_inteligente import seleccionInteligente
from .herr_seleccion import herrSeleccion
from .mod_navegacion import *

import os
import pyodbc

import numpy as np
import datetime

#esta es la direccion del proyecto
basepath = os.path.dirname(os.path.realpath(__file__))
conn = pyodbc.connect('driver={SQL Server};uid=sa;pwd=..;server=(local); database=gis;')
mnodos = ()
mlineas =()

class EnerGis5(object):

    def __init__(self, iface):
        self.iface = iface

        # Save reference to the QGIS interface
        self.iface = iface
        self.mapCanvas = iface.mapCanvas()
        self.utils = iface.mapCanvas().snappingUtils()

        #Creo una barra de herramientas
        self.actions = []
        self.menu = ('EnerGIS')
        self.toolbar = self.iface.addToolBar('EnerGIS')
        self.toolbar.setObjectName('EnerGIS')
        self.cb = QtWidgets.QApplication.clipboard()
        
        self.id_usuario_sistema = '0'

    def agregar_herramienta(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)            
        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            #self.iface.addPluginToVectorMenu(self.menu, action)
            pass
        self.actions.append(action)
        return action

    def transformToCurrentSRS(self, pPoint, srs):
        # transformation from provided srs to the current SRS
        crcMappaCorrente = self.iface.mapCanvas().mapSettings().destinationCrs() # get current crs
        #print crcMappaCorrente.srsid()
        crsDest = crcMappaCorrente
        crsSrc = core.QgsCoordinateReferenceSystem(srs)
        xform = core.QgsCoordinateTransform(crsSrc, crsDest, core.QgsProject.instance())
        return xform.transform(pPoint) # forward transformation: src -> dest

    def transformToWGS84(self, pPoint, srs):
        # transformation from the provided SRS to WGS84
        crsSrc = core.QgsCoordinateReferenceSystem(srs)
        crsDest = core.QgsCoordinateReferenceSystem(4326)  # WGS 84
        xform = core.QgsCoordinateTransform(crsSrc, crsDest, core.QgsProject.instance())
        return xform.transform(pPoint) # forward transformation: src -> dest

    def initGui(self):        
        img_candado = os.path.join(basepath,"icons", 'img_candado.png') 
        img_verificar = os.path.join(basepath,"icons", 'img_verificar.png')
        img_desconectados = os.path.join(basepath,"icons", 'img_desconectados.png')
        img_aislados = os.path.join(basepath,"icons", 'img_aislados.png')
        img_loops = os.path.join(basepath,"icons", 'img_loops.png')
        img_nav_extremos = os.path.join(basepath,"icons", 'img_nav_extremos.png')
        img_nav_fuente = os.path.join(basepath,"icons", 'img_nav_fuente.png')
        img_nav_fuentes = os.path.join(basepath,"icons", 'img_nav_fuentes.png')
        img_seleccion = os.path.join(basepath,"icons", 'img_seleccion.png')
        img_seleccion_inteligente = os.path.join(basepath,"icons", 'img_seleccion_inteligente.png')
        img_buscar = os.path.join(basepath,"icons", 'img_buscar.png')
        img_nodo = os.path.join(basepath,"icons", 'img_nodo.png')
        img_linea = os.path.join(basepath,"icons", 'img_linea.png')
        img_area = os.path.join(basepath,"icons", 'img_area.png')
        img_borrar = os.path.join(basepath,"icons", 'img_borrar.png')
		
        self.agregar_herramienta(img_candado, text=('LogIn'), callback=self.h_login, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_verificar, text=('Verificar Red'), callback=self.h_verificar_red, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_seleccion, text=('Selección'), callback=self.h_seleccion, enabled_flag=True, parent=self.iface.mainWindow())
        #herramienta 6 ----------------------------------------
        icon = QIcon(img_seleccion_inteligente)
        text="Selección Inteligente"
        parent=self.iface.mainWindow()
        action = QAction(icon, text, parent)
        action.triggered.connect(self.setMapTool)
        action.setCheckable(False)
        self.mapTool = seleccionInteligente(self.mapCanvas)
        self.mapTool.geomIdentified.connect(self.h_seleccion2)
        self.mapTool.setAction(action)
        self.toolbar.addAction(action)
        self.actions.append(action)
        #------------------------------------------------------
        self.agregar_herramienta(img_desconectados, text=('Desconectados'), callback=self.h_desconectados, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_aislados, text=('Aislados'), callback=self.h_aislados, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_loops, text=('Loops'), callback=self.h_loops, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_buscar, text=('Buscar'), callback=self.h_buscar, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_nodo, text=('Nodo'), callback=self.h_nodo, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_linea, text=('Linea'), callback=self.h_linea, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_area, text=('Area'), callback=self.h_area, enabled_flag=True, parent=self.iface.mainWindow())
        self.agregar_herramienta(img_borrar, text=('Borrar'), callback=self.h_borrar, enabled_flag=True, parent=self.iface.mainWindow())
        
    def unload(self):
        for action in self.actions:
            self.iface.removePluginVectorMenu('EnerGIS', action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def h_login(self):
        #LogIn
        if self.id_usuario_sistema=='0':
            from .frm_login import frmLogin
            dialogo = frmLogin()
            dialogo.exec()
            self.id_usuario_sistema = dialogo.id_usuario_sistema
            dialogo.close()
            #QMessageBox.information(None, 'EnerGis', 'Usuario conectado: ' + self.id_usuario_sistema)
            #habilito los botones
            #for action in self.actions:
            #    if action.text() == 'LogIn':
            #        action.setEnabled(False)
            #    if action.text() == 'Verificar Red':
            #        action.setEnabled(True)
            #    if action.text() == 'Desconectados':
            #        action.setEnabled(True)
            #    if action.text() == 'Aislados':
            #        action.setEnabled(True)
            #    if action.text() == 'Loops':
            #        action.setEnabled(True)
            pass
        
    def h_verificar_red(self):
        #Verificar Red
        #QMessageBox.information(None, 'EnerGis', 'Usuario: ' + self.id_usuario_sistema)
        #invoco las variables globales
        global conn
        global mnodos
        global mlineas
        #uso conexion local para que luego libere las tablas
        cnn = conn
        cursor = cnn.cursor()

        cursor.execute("""SELECT * FROM mLineas""")
        #convierto el cursor en array
        mlineas = tuple(cursor)
        cursor.close()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mNodos""")
        #convierto el cursor en array
        mnodos = tuple(cursor)
        cursor.close()

        cursor = cnn.cursor()
        cursor.execute("""SELECT aux FROM mNodos WHERE estado=1""")
        rows = cursor.fetchall()
        cursor.close()

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        layers = [mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            lyr.removeSelection()

        #f = open(os.path.join(basepath,"salidas", 'salida_navegacion.txt'), 'w')
        #f.write('\n' + 'Navegacion Red')
        #f.write('\n' + '--------------')
        #f.close()
            
        for x in range(0, len(mnodos)):
            mnodos[x][3] = 0
            mnodos[x][40] = 0
            mnodos[x][41] = 0

        for m in range (0, len(mlineas)):
            mlineas[m][4] = 0

        monodos = []
        for row in rows:
            r = navegar_compilar_red(monodos, mnodos, mlineas, row[0])
            if str(r) != 'Red Navegada':
                QMessageBox.information(None, 'EnerGis', str(r))
        
        seleccion_n = []
        for x in range(0, len(mnodos)):
            if mnodos[x][40] == 0:
                seleccion_n.append(mnodos[x][1])

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        for lyr in layers:
            if lyr.name() == 'Nodos 13200':
                lyr.select(seleccion_n)
            if lyr.name() == 'Nodos 400':
                lyr.select(seleccion_n)
        
    def h_desconectados(self):
        #Desconectados
        #invoco las variables globales
        global conn
        global mnodos
        global mlineas
        #uso conexion local para que luego libere las tablas
        cnn = conn
        cursor = cnn.cursor()

        cursor.execute("""SELECT * FROM mLineas""")
        #convierto el cursor en array
        mlineas = tuple(cursor)
        cursor.close()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mNodos""")
        #convierto el cursor en array
        mnodos = tuple(cursor)
        cursor.close()

        cursor = cnn.cursor()
        cursor.execute("""SELECT aux FROM mNodos WHERE estado=1""")
        rows = cursor.fetchall()
        cursor.close()

        #f = open(os.path.join(basepath,"salidas", 'salida_navegacion.txt'), 'w')
        #f.write('\n' + 'Deconectados')
        #f.write('\n' + '------------')
        #f.close()

        for x in range(0, len(mnodos)):
            mnodos[x][40] = 0
            mnodos[x][3] = 0

        for x in range(0, len(mlineas)):
            mlineas[x][4] = 0

        monodos = []
        for row in rows:
            r = navegar_compilar_red(monodos, mnodos, mlineas, row[0])
            if str(r) != 'Red Navegada':
                QMessageBox.information(None, 'EnerGis', str(r))
            pass

        seleccion_n = []
        for m in range (0, len(mnodos)):
            if mnodos[m][1] != 0:
                if mnodos[m][3] == 0:
                    seleccion_n.append(mnodos[m][1])

        seleccion_l = []
        for m in range (0, len(mlineas)):
            if mlineas[m][1] != 0:
                if mlineas[m][4] == 0:
                    seleccion_l.append(mlineas[m][1])

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        layers = [mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            lyr.removeSelection()

        #seleccionar en el mapa
        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        for lyr in layers:
            if lyr.name()[:6] == 'Lineas':
                lyr.select(seleccion_l)
            if lyr.name()[:5] == 'Nodos':
                lyr.select(seleccion_n)

        if len(seleccion_n) == 0:
            QMessageBox.information(None, 'EnerGis', 'No hay desconectados')
        else:
            from .frm_seleccion import frmSeleccion
            self.dialogo = frmSeleccion(mapcanvas)

            for m in range (0, len(seleccion_n)):
                self.dialogo.liwNodos.addItem(QListWidgetItem(str(seleccion_n[m])))

            for m in range (0, len(seleccion_l)):
                self.dialogo.liwLineas.addItem(QListWidgetItem(str(seleccion_l[m])))
            
            self.dialogo.show()
        pass
        
    def h_aislados(self):
        #Aislados
        #invoco las variables globales
        global conn
        global mnodos
        #uso conexion local para que luego libere las tablas
        cnn = conn
        cursor = cnn.cursor()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mNodos""")
        #convierto el cursor en array
        mnodos = tuple(cursor)
        cursor.close()

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        layers = [mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            lyr.removeSelection()

        seleccion_n = []
        for nodo in mnodos:
            if nodo[4]== 0:
                if nodo[0] != 0:
                    seleccion_n.append(nodo[1])

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        layers = [mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            lyr.removeSelection()

        #seleccionar en el mapa
        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        for lyr in layers:
            if lyr.name()[:5] == 'Nodos':
                lyr.select(seleccion_n)

        if len(seleccion_n) == 0:
            QMessageBox.information(None, 'EnerGis', 'No hay nodos aislados')
        else:
            from .frm_seleccion import frmSeleccion
            self.dialogo = frmSeleccion(mapcanvas)

            for m in range (0, len(seleccion_n)):
                self.dialogo.liwNodos.addItem(QListWidgetItem(str(seleccion_n[m])))

            self.dialogo.show()
        pass
        
    def h_loops(self):
        #Loops
        pass

    def h_buscar(self):
        global conn
        from .frm_buscar import frmBuscar
        mapcanvas = self.iface.mapCanvas()
        self.dialogo = frmBuscar(mapcanvas, conn)
        self.dialogo.show()
        pass

    def h_seleccion(self):

        tool = herrSeleccion(self.iface.mapCanvas())
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        seleccion_px = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_seleccion.png'))
        seleccion_px.setMask(seleccion_px.mask())
        seleccion_cursor = QtGui.QCursor(seleccion_px)
        self.mapCanvas.setCursor(seleccion_cursor)

        pass

    def h_seleccion2(self,layer,feature):
        self.selectedLayer = layer
        self.selectedFeature = feature
        #QMessageBox.information(None, 'EnerGis', str(self.selectedFeature.id()))
        self.contextMenuRequest()
        
    def setMapTool(self):
        self.mapCanvas.setMapTool(self.mapTool)        
        #Cambio el cursor
        seleccion_px = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_seleccion_inteligente.png'))
        seleccion_px.setMask(seleccion_px.mask())
        seleccion_cursor = QtGui.QCursor(seleccion_px)
        self.mapCanvas.setCursor(seleccion_cursor)
        #Otros cursores
        #self.mapCanvas.setCursor(QtGui.QCursor (QtCore.Qt.CrossCursor))
        #self.mapCanvas.setCursor(QtGui.QCursor (QtCore.Qt.WaitCursor))
        #self.mapCanvas.setCursor(QtGui.QCursor (QtCore.Qt.ArrowCursor))
        pass
        
    def contextMenuRequest(self):
        enable_disable = {True: "Habilitar", False: "Deshabilitar"}
        contextMenu = QMenu()
        self.clipboardLayerAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_capas.png")),"Capa: "+self.selectedLayer.name())
        if self.selectedLayer.type() == core.QgsMapLayer.VectorLayer:
            contextMenu.addSeparator()
            if self.selectedLayer.geometryType() == core.QgsWkbTypes.PointGeometry :
                self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_editar.png")),"Editar")
                self.setCurrentAction.triggered.connect(self.editarNodo)
                contextMenu.addSeparator()
                pp = self.transformToCurrentSRS(self.selectedFeature.geometry().asPoint(),self.selectedLayer.crs())
                pg = self.transformToWGS84(self.selectedFeature.geometry().asPoint(),self.selectedLayer.crs())
                self.lonLat = str(round(pg.x(),8))+","+str(round(pg.y(),8))
                self.xy = str(round(pp.x(),8))+","+str(round(pp.y(),8))
                self.clipboardXAction = contextMenu.addAction("X: "+str(round(pp.x(),2)))
                self.clipboardYAction = contextMenu.addAction("Y: "+str(round(pp.y(),2)))
                self.clipboardXAction.triggered.connect(self.clipboardXYFunc)
                self.clipboardYAction.triggered.connect(self.clipboardXYFunc)
                self.clipboardLonAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_propiedades.png")),"Lon: " + str(round(pg.x(),6)))
                self.clipboardLatAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_propiedades.png")),"Lat: " + str(round(pg.y(),6)))
                self.clipboardLonAction.triggered.connect(self.clipboardLonLatFunc)
                self.clipboardLatAction.triggered.connect(self.clipboardLonLatFunc)                
                contextMenu.addSeparator()
                self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_nav_fuente.png")),"Navegar a la Fuente")
                self.setCurrentAction.triggered.connect(self.navegarFuente)
                #self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_nav_fuentes.png")),"Caminos a Fuentes")
                #self.setCurrentAction.triggered.connect(self.navegarFuentes)
                self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_nav_extremos.png")),"Navegar a los Extremos")
                self.setCurrentAction.triggered.connect(self.navegarExtremos)
            elif self.selectedLayer.geometryType() == core.QgsWkbTypes.LineGeometry:
                self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_editar.png")),"Editar")
                self.setCurrentAction.triggered.connect(self.editarLinea)
                contextMenu.addSeparator()
                self.leng = round (self.selectedFeature.geometry().length(),2)
                bound = self.selectedFeature.geometry().boundingBox()
                self.clipboardNorthAction = contextMenu.addAction("N: "+str(round(bound.yMaximum(),4)))
                self.clipboardSouthAction = contextMenu.addAction("S: "+str(round(bound.yMinimum(),4)))
                self.clipboardEastAction = contextMenu.addAction("E: "+str(round(bound.xMinimum(),4)))
                self.clipboardWestAction = contextMenu.addAction("O: "+str(round(bound.xMaximum(),4)))
                self.clipboardLengAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_regla.png")),"Longitud Mapa: "+str(self.leng))
                self.clipboardLengAction.triggered.connect(self.clipboardLengFunc)
            elif self.selectedLayer.geometryType() == core.QgsWkbTypes.PolygonGeometry:
                self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_editar.png")),"Editar")
                self.setCurrentAction.triggered.connect(self.editarArea)
                contextMenu.addSeparator()
                self.area = round (self.selectedFeature.geometry().area(),2)
                self.leng = round (self.selectedFeature.geometry().length(),2)
                bound = self.selectedFeature.geometry().boundingBox() 
                self.clipboardNorthAction = contextMenu.addAction("N: "+str(round(bound.yMaximum(),4)))
                self.clipboardSouthAction = contextMenu.addAction("S: "+str(round(bound.yMinimum(),4)))
                self.clipboardEastAction = contextMenu.addAction("E: "+str(round(bound.xMinimum(),4)))
                self.clipboardWestAction = contextMenu.addAction("O: "+str(round(bound.xMaximum(),4)))
                self.clipboardLengAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_regla.png")),"Perimetro: "+str(self.leng))
                self.clipboardLengAction.triggered.connect(self.clipboardLengFunc)
                self.clipboardAreaAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_regla.png")),"Area: "+str(self.area))
                self.clipboardAreaAction.triggered.connect(self.clipboardAreaFunc)
        contextMenu.addSeparator()
        #self.setCurrentAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","mSetCurrentLayer.png")),"Set current layer")
        #self.hideAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","off.png")),"Hide")
        #self.openPropertiesAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","settings.svg")),"Open properties dialog")
        self.zoomToLayerAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_zoom_capa.png")),"Zoom a la capa")
        #self.setCurrentAction.triggered.connect(self.setCurrentFunc)
        #self.hideAction.triggered.connect(self.hideFunc)
        #self.openPropertiesAction.triggered.connect(self.openPropertiesFunc)
        self.zoomToLayerAction.triggered.connect(self.zoomToLayerFunc)
        if self.selectedLayer.type() == core.QgsMapLayer.VectorLayer:
        #    self.openAttributeTableAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","mActionOpenTable.png")),"Open attribute table")
        #    self.openAttributeTableAction.triggered.connect(self.openAttributeTableFunc)
        #    if self.selectedLayer.isEditable():
        #        self.stopEditingAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","mIconEditableEdits.png")),"Stop editing")
        #        self.stopEditingAction.triggered.connect(self.stopEditingFunc)
        #    else:
        #        self.startEditingAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","mIconEditable.png")),"Start editing")
        #        self.startEditingAction.triggered.connect(self.startEditingFunc)
            contextMenu.addSeparator()
            self.zoomToFeatureAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_zoom_elemento.png")),"Zoom al elemento seleccionado")
            self.zoomToFeatureAction.triggered.connect(self.zoomToFeatureFunc)
            if self.isSnappingOn(self.selectedLayer):
                self.snap_control = not core.QgsProject.instance().snappingConfig().individualLayerSettings(self.selectedLayer).enabled()
                self.snappingOptionsAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","img_snap.png")),enable_disable[self.snap_control]+" snap para esta capa")
                self.snappingOptionsAction.triggered.connect(self.snappingOptionsFunc)
        #    if len(QtWidgets.QApplication.clipboard().text().splitlines()) > 1:
        #        clipFeatLineTXT = QtWidgets.QApplication.clipboard().text().splitlines()[1]
        #        clipFeatsTXT = clipFeatLineTXT.split('\t')
        #        self.clipAttrsFieldnames = QtWidgets.QApplication.clipboard().text().splitlines()[0].split('\t')[1:]
        #        self.clipAttrsValues = clipFeatsTXT[1:]
        #        self.clipGeom = core.QgsGeometry.fromWkt(clipFeatsTXT[0])
        #        #if self.clipGeom.isGeosValid():
        #        if self.selectedLayer.isEditable() and self.clipGeom:
        #            self.pasteGeomAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","pasteIcon.png")),"Paste geometry on feature")
        #            self.pasteGeomAction.triggered.connect(self.pasteGeomFunc)
        #            self.pasteAttrsAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","pasteIcon.png")),"Paste attributes on feature")
        #            self.pasteAttrsAction.triggered.connect(self.pasteAttrsFunc)
        #    self.copyFeatureAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","copyIcon.png")),"Copy feature")
        #    self.copyFeatureAction.triggered.connect(self.copyFeatureFunc)
        #    self.attributeMenu = contextMenu.addMenu(QtGui.QIcon(os.path.join(basepath,"icons","viewAttributes.png")),"Feature attributes view")
        #    self.populateAttributesMenu(self.attributeMenu)
        #    self.editFeatureAction = contextMenu.addAction(QtGui.QIcon(os.path.join(basepath,"icons","mActionPropertyItem.png")),"Feature attributes edit")
        #    self.editFeatureAction.triggered.connect(self.editFeatureFunc)
        #    if self.selectedLayer.actions().actions():
        #        actionOrder = 0
        #        contextMenu.addSeparator()
        #        for action in self.selectedLayer.actions().actions():
        #            try:
        #                customIcon = action.icon()
        #            except:
        #                customIcon = QtGui.QIcon(os.path.join(basepath,"icons","customAction.png"))
        #            newActionItem = contextMenu.addAction(customIcon,action.name())
        #            newActionItem.triggered.connect(partial(self.customAction,actionOrder))
        #            actionOrder += 1
        contextMenu.exec_(QtGui.QCursor.pos())

    def clipboardXYFunc(self):
        self.cb.setText(self.xy)

    def clipboardLonLatFunc(self):
        self.cb.setText(self.lonLat)

    def clipboardLengFunc(self):
        self.cb.setText(str(self.leng))

    def clipboardAreaFunc(self):
        self.cb.setText(str(self.area))

    def editarNodo(self):
        QMessageBox.information(None, 'EnerGis', 'Editar Nodo ' + str(self.selectedFeature.id()))
        pass

    def editarLinea(self):
        QMessageBox.information(None, 'EnerGis', 'Editar Linea ' + str(self.selectedFeature.id()))
        pass

    def editarArea(self):
        QMessageBox.information(None, 'EnerGis', 'Editar Area ' + str(self.selectedFeature.id()))
        pass

    def navegarFuente(self):
        #invoco la conexion global
        global conn
        #uso conexion local para que luego libere la tabla
        cnn = conn
        global mnodos
        global mlineas
        
        #QMessageBox.information(None, 'EnerGis', 'nodo ' + str(self.selectedFeature.id()))
        cursor = cnn.cursor()
        cursor.execute("""SELECT Aux FROM mNodos WHERE Geoname=""" + str(self.selectedFeature.id()))
        rows = cursor.fetchall()
        cursor.close()
        for row in rows:
            nodo_ref = row[0]
        #QMessageBox.information(None, 'EnerGis', 'nodo_ref ' +  str(nodo_ref))

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        layers = [mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            lyr.removeSelection()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mLineas""")
        #convierto el cursor en array
        mlineas = tuple(cursor)
        cursor.close()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mNodos""")
        #convierto el cursor en array
        mnodos = tuple(cursor)
        cursor.close()

        #Esto demuesta que con numpy tarda el doble !
        #--------------------------------------------
        #npmnodos = np.asarray(mnodos, dtype = np.int32)
        #npmlineas = np.asarray(mlineas, dtype = np.int32)
        #i1 = datetime.datetime.now()
        #for m in range (0, len(mnodos)):
        #    for n in range (0, 5000):
        #        lpm = mnodos[n][7]
        #f1 = datetime.datetime.now()
        #i2 = datetime.datetime.now()
        #for m in range (0, 5000):
        #    for n in range (0, len(npmnodos)):
        #        lpm = npmnodos[n][7]
        #f2 = datetime.datetime.now()
        #QMessageBox.information(None, 'EnerGis', str(i1) + ' ' + str(f1) + ' / ' + str(i2) + ' ' + str(f2))
        #pass
        
        if len(mnodos) == 0:
            QMessageBox.information(None, 'EnerGis', 'Cargar Red')
        else:
            if len(mlineas) == 0:
                QMessageBox.information(None, 'EnerGis', 'Cargar Red')
                pass
            
        fuentes = []
        cursor = cnn.cursor()
        cursor.execute("""SELECT Aux FROM mNodos WHERE Estado=1""")
        rows = cursor.fetchall()
        cursor.close()
        for row in rows:
            fuentes.append(row[0])
        
        for m in range (0, len(mlineas)):
            mlineas[m][7] = 0
            
        lineas_ordenadas = []
        r = navegar_a_la_fuente(mnodos, mlineas, nodo_ref, fuentes, lineas_ordenadas)
        #QMessageBox.information(None, 'EnerGis', str(r))
        
        #seleccionar en el mapa el camino
        seleccion_l = []
        seleccion_n = []
        for linea in mlineas:
            if linea[7] != 0:
                seleccion_l.append(linea[1])

                existe1 = False
                existe2 = False
                for i in range(0, len(seleccion_n)):
                    if seleccion_n[i] == mnodos[linea[2]][1]:
                        existe1 = True
                    if seleccion_n[i] == mnodos[linea[3]][1]:
                        existe2 = True
                
                if existe1 == False:
                    seleccion_n.append (mnodos[linea[2]][1])

                if existe2 == False:
                    seleccion_n.append(mnodos[linea[3]][1])
                
        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        for lyr in layers:
            if lyr.name()[:5] == 'Nodos':
                lyr.select(seleccion_n)
            if lyr.name()[:6] == 'Lineas':
                lyr.select(seleccion_l)

        if len(seleccion_n) == 0:
            QMessageBox.information(None, 'EnerGis', 'No hay fuentes conectadas')
        else:
            from .frm_seleccion import frmSeleccion
            self.dialogo = frmSeleccion(mapcanvas)

            for m in range (0, len(seleccion_n)):
                self.dialogo.liwNodos.addItem(QListWidgetItem(str(seleccion_n[m])))

            for m in range (0, len(seleccion_l)):
                self.dialogo.liwLineas.addItem(QListWidgetItem(str(seleccion_l[m])))
            
            self.dialogo.show()
        pass
                
    def navegarExtremos(self):
        #QMessageBox.information(None, 'EnerGis', 'navegarExtremos ' + str(self.selectedFeature.id()))
        #QMessageBox.information(None, 'EnerGis', 'nodo ' + str(self.selectedFeature.id()))
        #QMessageBox.information(None, 'EnerGis', 'usuario ' +  self.id_usuario_sistema)

        #invoco la conexion global
        global conn
        #uso conexion local para que luego libere la tabla
        cnn = conn
        global mnodos
        global mlineas

        #QMessageBox.information(None, 'EnerGis', 'nodo ' + str(self.selectedFeature.id()))
        cursor = cnn.cursor()
        cursor.execute("""SELECT Aux FROM mNodos WHERE Geoname=""" + str(self.selectedFeature.id()))
        rows = cursor.fetchall()
        cursor.close()
        for row in rows:
            nodo_ref = row[0]
        #QMessageBox.information(None, 'EnerGis', 'nodo_ref ' +  str(nodo_ref))

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        layers = [mapcanvas.layer(i) for i in range(n)]
        for lyr in layers:
            lyr.removeSelection()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mLineas""")
        #convierto el cursor en array
        mlineas = tuple(cursor)
        cursor.close()

        cursor = cnn.cursor()
        cursor.execute("""SELECT * FROM mNodos""")
        #convierto el cursor en array
        mnodos = tuple(cursor)
        cursor.close()

        if len(mnodos) == 0:
            QMessageBox.information(None, 'EnerGis', 'Cargar Red')
        else:
            if len(mlineas) == 0:
                QMessageBox.information(None, 'EnerGis', 'Cargar Red')
                pass
            
        fuentes = []
        cursor = cnn.cursor()
        cursor.execute("""SELECT Aux FROM mNodos WHERE Estado=1""")
        rows = cursor.fetchall()
        cursor.close()
        for row in rows:
            fuentes.append(row[0])

        for m in range (0, len(mlineas)):
            mlineas[m][7] = 0

        for m in range (0, len(mnodos)):
            mnodos[m][40] = 0

        r = navegar_a_los_extremos (mnodos, mlineas, nodo_ref, fuentes)
        if r == None:
            pass
        else:
            QMessageBox.information(None, 'EnerGis', str(r))
        
        #seleccionar en el mapa el camino
        seleccion_l = []
        for m in range (0, len(mlineas)):
            if mlineas[m][1] != 0:
                if mlineas[m][7] != 0:
                    seleccion_l.append(mlineas[m][1])

        seleccion_n = []
        for m in range (0, len(mnodos)):
            if mnodos[m][1] != 0:
                if mnodos[m][40] != 0:
                    seleccion_n.append(mnodos[m][1])

        mapcanvas = self.iface.mapCanvas()
        n = mapcanvas.layerCount()
        for lyr in layers:
            if lyr.name()[:6] == 'Lineas':
                lyr.select(seleccion_l)
            if lyr.name()[:5] == 'Nodos':
                lyr.select(seleccion_n)

        if len(seleccion_n) == 0:
            QMessageBox.information(None, 'EnerGis', 'No hay nodos aguas abajo')
        else:
            from .frm_seleccion import frmSeleccion
            self.dialogo = frmSeleccion(mapcanvas)

            for m in range (0, len(seleccion_n)):
                self.dialogo.liwNodos.addItem(QListWidgetItem(str(seleccion_n[m])))

            for m in range (0, len(seleccion_l)):
                self.dialogo.liwLineas.addItem(QListWidgetItem(str(seleccion_l[m])))
            
            self.dialogo.show()
        pass

    def navegarFuentes(self):
    #    QMessageBox.information(None, 'EnerGis', 'navegarFuentes ' + str(self.selectedFeature.id()))
        pass

    def zoomToFeatureFunc(self):
        featureBox = self.selectedFeature.geometry().boundingBox()
        p1 = self.transformToCurrentSRS(core.QgsPointXY(featureBox.xMinimum(),featureBox.yMinimum()),self.selectedLayer.crs())
        p2 = self.transformToCurrentSRS(core.QgsPointXY(featureBox.xMaximum(),featureBox.yMaximum()),self.selectedLayer.crs())
        self.mapCanvas.setExtent(core.QgsRectangle(p1.x(),p1.y(),p2.x(),p2.y()))
        self.mapCanvas.refresh()
        pass
            
    def zoomToLayerFunc(self):
        layerBox = self.selectedLayer.extent()
        p1 = self.transformToCurrentSRS(core.QgsPointXY(layerBox.xMinimum(),layerBox.yMinimum()),self.selectedLayer.crs())
        p2 = self.transformToCurrentSRS(core.QgsPointXY(layerBox.xMaximum(),layerBox.yMaximum()),self.selectedLayer.crs())
        self.mapCanvas.setExtent(core.QgsRectangle(p1.x(),p1.y(),p2.x(),p2.y()))
        self.mapCanvas.refresh()
        pass

    def isSnappingOn(self,layer):
        globalSnappingConfig = core.QgsProject.instance().snappingConfig()
        return globalSnappingConfig.enabled() and globalSnappingConfig.mode() == core.QgsSnappingConfig.AdvancedConfiguration
        pass
        
    def snappingOptionsFunc(self):
        globalSnappingConfig = core.QgsProject.instance().snappingConfig()
        layerSnapConfig = globalSnappingConfig.individualLayerSettings(self.selectedLayer)
        layerSnapConfig.setEnabled(self.snap_control)
        globalSnappingConfig.setIndividualLayerSettings(self.selectedLayer, layerSnapConfig)
        core.QgsProject.instance().setSnappingConfig(globalSnappingConfig)
        pass

    def h_nodo(self):
        pass
        
    def h_linea(self):
        pass
        
    def h_area(self):
        pass
        
    def h_borrar(self):
        pass