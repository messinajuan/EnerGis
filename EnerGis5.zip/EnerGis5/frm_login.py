﻿import os
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import uic
from qgis.utils import iface
import pyodbc

DialogBase, DialogType = uic.loadUiType(os.path.join(os.path.dirname(__file__),'frm_login.ui'))

class frmLogin(DialogType, DialogBase):

    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.cargarUsuario()
        self.buttonBox.accepted.connect(self.aceptar)
        self.buttonBox.rejected.connect(self.salir)
        self.id_usuario_sistema = '0'

    def cargarUsuario(self):
        self.textUsuario.setText('')
    
    def aceptar(self):
        conn = pyodbc.connect('driver={SQL Server};uid=sa;pwd=..;server=(local); database=gis;')
        cursor = conn.cursor()
        cursor.execute("""SELECT * FROM usuarios_sistema WHERE us_aplicacion='energis' AND us_nombre_usuario='""" + str(self.textUsuario.text()) + """'""")
        rows = cursor.fetchall()
        cursor.close()
        
        for row in rows:
            if str(self.textPassword.text()) == str(row[3]):
                self.id_usuario_sistema = str(row[0])                        
                #me agrego a la lista de sesiones
                cursor = conn.cursor()
                cursor.execute("""UPDATE usuarios_sistema SET us_logged=1 WHERE us_aplicacion='energis' AND id_usuario_sistema=""" + self.id_usuario_sistema)
                cursor.close()
                QMessageBox.information(None, 'EnerGis', 'Conectado !')
                self.close()
            else:
                self.textPassword.setText('')
        
    def salir(self):
        #iface.messageBar().pushMessage('Antes de Salir')
        self.close()
